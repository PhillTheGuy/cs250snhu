import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class TopFiveDestinationList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
                topDestinationListFrame.setTitle("Top 5 Destination List");
                topDestinationListFrame.setVisible(true);
            }
        });
    }
}


class TopDestinationListFrame extends JFrame {
    private DefaultListModel listModel;

    public TopDestinationListFrame() {
        super("Top Five Destination List");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 750);

        listModel = new DefaultListModel();


        //5 locations with pictures from wikimedia commons with names of authors
        addDestinationNameAndPicture("1. Tsu Castle, Mie Prefecture Japan A great place to see the charry blossoms in front of the castle (Photo: 663highland))", new ImageIcon(getClass().getResource("/resources/512px-140405_Tsu_Castle_Tsu_MIe_pref_Japan01s.jpg")));
        addDestinationNameAndPicture("2.  Las Vegas Nevada The Strip, One of the biggest sets of lights and sounds you will never get board of. (Photo: Dietmar Rabich)", new ImageIcon(getClass().getResource("/resources/512px-Las_Vegas_(Nevada,_USA),_The_Strip_--_2012_--_6232.jpg")));
        addDestinationNameAndPicture("3. Stockholm Sweden, A beautiful place where Old world and new world archatecture come to meet (Photo: Liridon)", new ImageIcon(getClass().getResource("/resources/512px-Stockholm_-_city_views_-_April_2019.jpg")));
        addDestinationNameAndPicture("4.  Monaco, One of the beautiful places along side the French Riviera(Photo: Diego Delso) ", new ImageIcon(getClass().getResource("/resources/512px-Vista_de_Mónaco,_2016-06-23,_DD_12.jpg")));
        addDestinationNameAndPicture("5. Oaxaca City, Mexico is one of Mexicos primary mezcal produceing regions so you can enjoy drinks from dusk till dawn(Photo: Michael Holloway)", new ImageIcon(getClass().getResource("/resources/512px-Oaxaca_City_street.jpg")));
        
        JList list = new JList(listModel);
        JScrollPane scrollPane = new JScrollPane(list);

        TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(2);
        //Set colors for when selection is clicked or not
        list.setBackground(Color.GRAY);
        list.setSelectionBackground(Color.CYAN);
        list.setCellRenderer(renderer);
        JLabel nameLabel = new JLabel("Developer: Phillip Kimbrel");
        //Added Name Pane for Dev name
        getContentPane().add(nameLabel, BorderLayout.NORTH);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

    private void addDestinationNameAndPicture(String text, Icon icon) {
        TextAndIcon tai = new TextAndIcon(text, icon);
        listModel.addElement(tai);
    }
}


class TextAndIcon {
    private String text;
    private Icon icon;

    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }
}


class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer {
    private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);

    private Border insideBorder;

    public TextAndIconListCellRenderer() {
        this(0, 0, 0, 0);
    }

    public TextAndIconListCellRenderer(int padding) {
        this(padding, padding, padding, padding);
    }

    public TextAndIconListCellRenderer(int topPadding, int rightPadding, int bottomPadding, int leftPadding) {
        insideBorder = BorderFactory.createEmptyBorder(topPadding, leftPadding, bottomPadding, rightPadding);
        setOpaque(true);
    }

    public Component getListCellRendererComponent(JList list, Object value,
    int index, boolean isSelected, boolean hasFocus) {
        // The object from the combo box model MUST be a TextAndIcon.
        TextAndIcon tai = (TextAndIcon) value;

        // Sets text and icon on 'this' JLabel.
        setText(tai.getText());
        setIcon(tai.getIcon());

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder;

        if (hasFocus) {
            outsideBorder = UIManager.getBorder("List.focusCellHighlightBorder");
        } else {
            outsideBorder = NO_FOCUS_BORDER;
        }

        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());

        return this;
    }

    // The following methods are overridden to be empty for performance
    // reasons. If you want to understand better why, please read:
    //
    // http://java.sun.com/javase/6/docs/api/javax/swing/DefaultListCellRenderer.html#override

    public void validate() {}
    public void invalidate() {}
    public void repaint() {}
    public void revalidate() {}
    public void repaint(long tm, int x, int y, int width, int height) {}
    public void repaint(Rectangle r) {}
}